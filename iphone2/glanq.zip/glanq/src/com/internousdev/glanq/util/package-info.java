/**
 * 
 */
/**
 * @author インターノウス
 *
 */
package com.internousdev.glanq.util;