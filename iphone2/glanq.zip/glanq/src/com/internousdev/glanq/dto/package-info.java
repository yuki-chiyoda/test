/**
 * 
 */
/**
 * @author インターノウス
 *
 */
package com.internousdev.glanq.dto;