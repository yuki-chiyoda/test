package com.internousdev.glanq.action;

import com.opensymphony.xwork2.ActionSupport;

public class TimeoutAction extends ActionSupport{
    public String execute(){
    	return SUCCESS;
    }
}
