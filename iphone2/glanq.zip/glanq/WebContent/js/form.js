/**
 *
 */


	$(document).ready(function() {
		//Input Lock(入力するとラベルが固定されるように設定しよう！)

		//1個目のラベル用
		$('.field:first-child .txt').blur(function() {
			$('.field:first-child .txt').each(function() {
				$this = $(this);
				if (this.value != '') {
					$this.addClass('focused');
					$('.field:first-child .defaultLabel').addClass('focused');
					$('.field:first-child  .txt + .accordion + .nice').css({
						'opacity' : 1
					});
				} else {
					$this.removeClass('focused');
					$('.field:first-child .defaultLabel').removeClass('focused');
					$('.field:first-child .txt + .accordion + .nice').css({
						'opacity' : 0
					});
				}
			});
		});

		//2個目のラベル用
		$('.field:nth-child(2) .txt').blur(function() {
			$('.field:nth-child(2) .txt').each(function() {
				$this = $(this);
				if (this.value != '') {
					$this.addClass('focused');
					$('.field:nth-child(2) .defaultLabel').addClass('focused');
					$('.field:nth-child(2) .txt + .accordion + .nice').css({
						'opacity' : 1
					});
				} else {
					$this.removeClass('focused');
					$('.field:nth-child(2) .defaultLabel').removeClass('focused');
					$('.field:nth-child(2) .txt + .accordion + .nice').css({
						'opacity' : 0
					});
				}
			});
		});

		//3個目のラベル用
		$('.field:nth-child(3) .txt').blur(function() {
			$('.field:nth-child(3) .txt').each(function() {
				$this = $(this);
				if (this.value != '') {
					$this.addClass('focused');
					$('.field:nth-child(3) .defaultLabel').addClass('focused');
					$('.field:nth-child(3) .txt + .accordion + .nice').css({
						'opacity' : 1
					});
				} else {
					$this.removeClass('focused');
					$('.field:nth-child(3) .defaultLabel').removeClass('focused');
					$('.field:nth-child(3) .txt + .accordion + .nice').css({
						'opacity' : 0
					});
				}
			});
		});

		//4個目のラベル用
		$('.field:nth-child(4) .txt').blur(function() {
			$('.field:nth-child(4) .txt').each(function() {
				$this = $(this);
				if (this.value != '') {
					$this.addClass('focused');
					$('.field:nth-child(4) .defaultLabel').addClass('focused');
					$('.field:nth-child(4) .txt + .accordion + .nice').css({
						'opacity' : 1
					});
				} else {
					$this.removeClass('focused');
					$('.field:nth-child(4) .defaultLabel').removeClass('focused');
					$('.field:nth-child(4) .txt + .accordion + .nice').css({
						'opacity' : 0
					});
				}
			});
		});

		//5個目のラベル用
		$('.field:nth-child(5) .txt').blur(function() {
			$('.field:nth-child(5) .txt').each(function() {
				$this = $(this);
				if (this.value != '') {
					$this.addClass('focused');
					$('.field:nth-child(5) .defaultLabel').addClass('focused');
					$('.field:nth-child(5) .txt + .accordion + .nice').css({
						'opacity' : 1
					});
				} else {
					$this.removeClass('focused');
					$('.field:nth-child(5) .defaultLabel').removeClass('focused');
					$('.field:nth-child(5) .txt + .accordion + .nice').css({
						'opacity' : 0
					});
				}
			});
		});

		//6個目のラベル用
		$('.field:nth-child(6) .txt').blur(function() {
			$('.field:nth-child(6) .txt').each(function() {
				$this = $(this);
				if (this.value != '') {
					$this.addClass('focused');
					$('.field:nth-child(6) .defaultLabel').addClass('focused');
					$('.field:nth-child(6) .txt + .accordion + .nice').css({
						'opacity' : 1
					});
				} else {
					$this.removeClass('focused');
					$('.field:nth-child(6) .defaultLabel').removeClass('focused');
					$('.field:nth-child(6) .txt + .accordion + .nice').css({
						'opacity' : 0
					});
				}
			});
		});

		//7個目のラベル用
		$('.field:nth-child(7) .txt').blur(function() {
			$('.field:nth-child(7) .txt').each(function() {
				$this = $(this);
				if (this.value != '') {
					$this.addClass('focused');
					$('.field:nth-child(7) .defaultLabel').addClass('focused');
					$('.field:nth-child(7) .txt + .accordion + .nice').css({
						'opacity' : 1
					});
				} else {
					$this.removeClass('focused');
					$('.field:nth-child(7) .defaultLabel').removeClass('focused');
					$('.field:nth-child(7) .txt + .accordion + .nice').css({
						'opacity' : 0
					});
				}
			});
		});

		//8個目のラベル用
		$('.field:nth-child(8) .txt').blur(function() {
			$('.field:nth-child(8) .txt').each(function() {
				$this = $(this);
				if (this.value != '') {
					$this.addClass('focused');
					$('.field:nth-child(8) .defaultLabel').addClass('focused');
					$('.field:nth-child(8) .txt + .accordion + .nice').css({
						'opacity' : 1
					});
				} else {
					$this.removeClass('focused');
					$('.field:nth-child(8) .defaultLabel').removeClass('focused');
					$('.field:nth-child(8) .txt + .accordion + .nice').css({
						'opacity' : 0
					});
				}
			});
		});

		//9個目のラベル用
		$('.field:nth-child(9) .txt').blur(function() {
			$('.field:nth-child(9) .txt').each(function() {
				$this = $(this);
				if (this.value != '') {
					$this.addClass('focused');
					$('.field:nth-child(9) .defaultLabel').addClass('focused');
					$('.field:nth-child(9) .txt + .accordion + .nice').css({
						'opacity' : 1
					});
				} else {
					$this.removeClass('focused');
					$('.field:nth-child(9) .defaultLabel').removeClass('focused');
					$('.field:nth-child(9) .txt + .accordion + .nice').css({
						'opacity' : 0
					});
				}
			});
		});

		//10個目のラベル用
		$('.field:nth-child(10) .txt').blur(function() {
			$('.field:nth-child(10) .txt').each(function() {
				$this = $(this);
				if (this.value != '') {
					$this.addClass('focused');
					$('.field:nth-child(10) .defaultLabel').addClass('focused');
					$('.field:nth-child(10) .txt + .accordion + .nice').css({
						'opacity' : 1
					});
				} else {
					$this.removeClass('focused');
					$('.field:nth-child(10) .defaultLabel').removeClass('focused');
					$('.field:nth-child(10) .txt + .accordion + .nice').css({
						'opacity' : 0
					});
				}
			});
		});

		//10個もいらないって？念のためだよ

	});